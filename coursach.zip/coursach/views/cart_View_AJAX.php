<h2 class="h2_cart menublock">Корзина</h2>
<?php if(isset($_SESSION['products_cart'])): ?>

  <table class="table_cart" border="1px">
    <tr>
      <th><center>Код товара</center></th>
      <th><center>Название товара</center></th>
      <th><center>Стоимость, грн</center></th>
      <th><center>Количество, шт</center></th>

    </tr>
    <?php $sum=0; ?>
    <?php foreach ($data as $product): ?>

      <tr>

        <td><center><?php echo $product['code']; ?></center></td>
        <td><center><?php echo $product['name']; ?></center></td>
        <td><center><?php echo $product['price']; ?></center></td>
        <td><center id="<?php echo $product['id'];  ?>"><?php echo $_SESSION['products_cart'][$product['id']];  ?></center></td>
        <td> <button type="button" name="button" onclick="remove_to_cart(<?php echo $product['id'];  ?>)">Убрать товар из корзины</button> </td>

      </tr>
    <?php $sum+=$product['price']*$_SESSION['products_cart'][$product['id']]; ?>
    <?php endforeach; ?>
    <tr class="">
      <th>Общая стоимость:</th>
      <th></th>
      <th></th>
      <th></th>
      <td><?php echo $sum.' грн'; ?></td>
    </tr>
  </table>
<button class="button_cart" type="button" name="button" onclick="clear_cart()">Очистить корзину</button> <a class="a_cart" href="/cart/order_emiter">Оформление заказа</a>

<?php else: ?>

    <h3 class="h3_cart">Ваша корзина пуста</h3>

<?php endif; ?>
