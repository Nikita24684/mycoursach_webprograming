

<?php if(my_cabinet_Model::checkAdmin()): ?>

<div class="cabinet">

<center><h2>Личный кабинет</h2></center>

<h3>Здраствуйте <?php echo $_SESSION['logged_user']['name']; ?></h3>

<a class="a_cabinet" href="/my_cabinet/edit_user">Редактировать данные пользователя</a><br>

<a class="a_cabinet" href="/my_cabinet/manage_of_orders">Управление заказами</a><br>

<a class="a_cabinet" href="/my_cabinet/manage_of_category">Управление категориями</a><br>

<a class="a_cabinet" href="/my_cabinet/manage_of_products">Управление товарами</a><br>

<a class="a_cabinet" href="/my_cabinet/logout">Выйти</a>

</div>

<?php else: ?>
  <h1 style="color: red;">У вас нет прав доступа к данной панели!</h1>
<?php endif; ?>
