

<?php if(isset($_SESSION['logged_user'])): ?>

<a class="a_edit" href="/my_cabinet/edit_user_name">Изменить имя</a><br>

<a class="a_edit" href="/my_cabinet/edit_user_email">Изменить привязанный email</a><br>

<a class="a_edit" href="/my_cabinet/edit_user_password">Изменить пароль</a>

<?php else: ?>
  <h1 style="color: red;">У вас нет прав доступа к данной панели!</h1>
<?php endif; ?>
