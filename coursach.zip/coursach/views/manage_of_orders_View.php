

<?php if(my_cabinet_Model::checkAdmin()): ?>
<table border="1px">
<tr>
  <th>Номер заказа</th>
  <th>Имя заказчика</th>
  <th>Номер телефона заказчика</th>
  <th>E-mail заказчика</th>
  <th>Дополнительные пожелания заказчика</th>
  <th>ID заказчика если он зарегистрирован</th>
  <th>Дата заказа</th>
  <th>Список заказанных товаров</th>
  <th>Принят ли заказ</th>
</tr>
<?php foreach ($data as $order): ?>
  <tr>
    <td><?php echo $order['id']; ?></td>
    <td><?php echo $order['user_name']; ?></td>
    <td><?php echo $order['user_phone']; ?></td>
    <td><?php echo $order['user_email']; ?></td>
    <td><?php echo $order['user_comment']; ?></td>
    <td><?php echo $order['user_id']; ?></td>
    <td><?php echo $order['date']; ?></td>
    <td><?php echo $order['products']; ?></td>
    <td><p id="<?php echo $order['status'].'p'.$order['id']; ?>" class="ps"><?php  if($order['status']==0){
         echo 'Нет';
     }
     else{
         echo 'Да';
     } ?></p></td>
    <td><input id="<?php echo $order['id']; ?>" onclick="accept_order(<?php echo $order['id']; ?>, <?php echo $order['status']; ?>)" type="button" name="button" value="<?php
     if($order['status']==0){
         echo 'Пометить как принятый';
     }
     else{
         echo 'Снять отметку';
     }
     ?>"><br><input onclick="delete_order(<?php echo $order['id']; ?>)" type="button" name="delete" value="Удалить"></td>
  </tr>
<?php endforeach; ?>
</table>
<?php else: ?>
  <h1 style="color: red;">У вас нет прав доступа к данной панели!</h1>
<?php endif; ?>
<script type="text/javascript">

    function accept_order(id, status){



        $.ajax({
            type: 'POST',
            url: '#',
            data: {'button': id,
                   'status': status
                   },
            success: function(response){
                $('body').html('<body>'+response+'</body>');
            }
        });

    }



    function delete_order(id){




        $.ajax({
            type: 'POST',
            url: '#',
            data: {'delete': id},
            success: function(response){
                $('body').html('<body>'+response+'</body>');
            }
        });

    }


</script>
