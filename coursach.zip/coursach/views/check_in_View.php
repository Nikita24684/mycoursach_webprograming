
<form class="check_in" action="#" method="POST">

<p>
<p><strong>Ваше имя:</strong></p>
<input type="text" name="name" value="<?php echo $data['login']; ?>">
</p>
<p>
<p><strong>Ваш e-mail:</strong></p>
<input type="email" name="email" value="<?php echo $data['email']; ?>">
</p>
<p>
<p><strong>Ваш пароль:</strong></p>
<input type="password" name="password" value="<?php echo $data['password']; ?>">
</p>
<p><strong>Повторите ваш пароль:</strong></p>
<input type="password" name="password_2" value="<?php echo $data['password_2']; ?>">
</p>

<button type="submit" name="do_check_in">Зарегистрироваться</button>
</form>
