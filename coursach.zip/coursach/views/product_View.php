
<div class="product">

  <center><h2><?php echo $data['name']; ?></h2></center><br>
  <center><img src=<?php if($data['image']!=NULL) echo '/'.$data['image']; else echo '/views/images/not_image.png'; ?> style="max-width: 180px; max-height: 220px;" alt=""></center>
  <center><h3><?php echo $data['price']; ?> грн</h3></center><br>
  <center><button class="button_cart_product" type="button" name="button" onclick="add_to_cart(<?php echo $data['id']; ?>)">В корзину</button></center>
  <h3>Характеристики/описание:</h3><br>
  <p><?php echo $data['description']; ?></p>
</div>
