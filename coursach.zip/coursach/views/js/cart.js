

function add_to_cart(id){


  $.ajax({
      type: 'POST',
      url: '/category/addproduct',
      data: {
          'id_add': id

      },
      success: function(response){
          $('#cart_count').html(response);
      }
  });
}
function remove_to_cart(id){


    $.ajax({
        type: 'POST',
        url: '/cart/delproduct',
        data: {
            'id_del': id

        },
        success: function(response){
            $('#pagecart').html(response);
        }
    });

    $.ajax({
        type: 'POST',
        url: '/cart/countreducer',
        data: {
            'id_del': id

        },
        success: function(response){
            $('#cart_count').html(response);
        }
    });

}

function clear_cart(){


    $.ajax({
        type: 'POST',
        url: '/cart/clearcart',
        data: {
            'clear_cart': 'clear'

        },
        success: function(response){
            $('#pagecart').html(response);
        }
    });

    $.ajax({
        type: 'POST',
        url: '/cart/countreducer',
        data: {
            'clear_cart': 'clear'

        },
        success: function(response){
            $('#cart_count').html(response);
        }
    });

}
