
<div class="order_emit">
<?php if(isset($_SESSION['products_cart'])): ?>

<center><h2>Для оформления заказа заполните форму. Наш менеджер свяжется с Вами.</h2></center>
<form class="" action="#" method="post">

  Имя:<input type="text" name="user_name" value="<?php if(isset($_SESSION['logged_user'])) echo $_SESSION['logged_user']['name']; ?>"><br>
  Номер телефона:<input type="text" name="number_phone" value=""><br>
  E-mail:<input type="text" name="user_email" value="<?php if(isset($_SESSION['logged_user'])) echo $_SESSION['logged_user']['email']; ?>"><br>
  Дополнительные пожелания:<input type="text" name="user_comment" value="">
  <input type="submit" name="order_emiter" value="Оформить заказ">
</form>

<?php else: ?>

  <h1>Мы с вами свяжемся;)</h1>
  <a href="/">Вернуться к покупкам</a>

<?php endif; ?>

</div>
