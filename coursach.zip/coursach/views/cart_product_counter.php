<?php
echo $_SESSION['products_cart'][$product['id']];
?>
