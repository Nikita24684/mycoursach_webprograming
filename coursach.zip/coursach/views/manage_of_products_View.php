
<?php if(my_cabinet_Model::checkAdmin()): ?>
<table id="table_products" border="1px">
  <tr>
    <th>id</th>
    <th>Название</th>
    <th>Категория</th>
    <th>Код товара</th>
    <th>Цена</th>
    <th>Наличие</th>
    <th>Брэнд</th>
    <th>Описание/характеристики</th>
    <th>Является ли новым</th>
    <th>Рекомендован ли</th>
    <th>Прибыл ли на склад</th>
    <th>Фото товара</th>
  </tr>

  <?php foreach($data as $product): ?>
    <tr><form id="<?php echo $product['id']; ?>" class="edit_product" action="" method="post" enctype="multipart/form-data">
      <td><select id="<?php echo $product['id']; ?>" name="id"><option selected value="<?php echo $product['id']; ?>"><?php echo $product['id']; ?></option></select></td>
      <td><input id="name<?php echo $product['id']; ?>" type="text" name="name" value="<?php echo $product['name']; ?>"></td>
      <td><select id="category<?php echo $product['id']; ?>" name="category"><?php foreach (Model::get_data() as $category):?><option <?php if($category['id']==$product['category_id']) echo 'selected value='; else echo 'value='; ?>"<?php echo $category['id'].'-'.$category['name']; ?>"><?php echo $category['id'].'-'.$category['name']; ?></option><?php endforeach; ?></select></td>

      <td><input id="code<?php echo $product['id']; ?>" name="code" type="text" value="<?php echo $product['code']; ?>"></td>
      <td><input id="price<?php echo $product['id']; ?>" name="price" type="text" value="<?php echo $product['price']; ?>"></td>
      <td><select id="availability<?php echo $product['id']; ?>" name="availability"><option <?php if($product['availability']==1) echo 'selected value='; else echo 'value'; ?>"Да">Да</option><option <?php if($product['availability']==0) echo 'selected value='; else echo 'value='; ?>"Нет" >Нет</option></select></td>

      <td><input id="brand<?php echo $product['id']; ?>" type="text" name="brand" value="<?php echo $product['brand']; ?>"></td>
      <td><input id="description<?php echo $product['id']; ?>" type="text" name="description" value="<?php echo $product['description']; ?>"></td>
      <td><select id="is_new<?php echo $product['id']; ?>" name="is_new"><option <?php if($product['is_new']==1) echo 'selected value='; else echo 'value='; ?>"Да">Да</option><option <?php if($product['is_new']==0) echo 'selected value='; else echo 'value='; ?>"Нет" >Нет</option></select></td>
      <td><select id="is_recommended<?php echo $product['id']; ?>" name="is_recommended"><option <?php if($product['is_recommended']==1) echo 'selected value='; else echo 'value'; ?>"Да">Да</option><option <?php if($product['is_recommended']==0) echo 'selected value='; else echo 'value='; ?>"Нет" >Нет</option></select></td>
      <td><select id="status<?php echo $product['id']; ?>" name="status"><option <?php if($product['status']==1) echo 'selected value='; else echo 'value='; ?>"Да">Да</option><option <?php if($product['status']==0) echo 'selected value='; else echo 'value='; ?>"Нет" >Нет</option></select></td>

      <td><img src="<?php ROOT ?>../<?php echo $product['image']; ?>" style="max-width: 320px; max-height: 320px;" alt=""><br> <input id="delimg<?php echo $product['id']; ?>" type="checkbox" name="del_img" value="del_img">Удалить фото<br><input id="image<?php echo $product['id']; ?>" type="file" name="image" value=""></td>
      <td><input type="submit" name="edit_product" value="Сохранить"></td>
      </form>
      <td>
          <button name="delete_product" onclick="delete_product(<?php echo $product['id']; ?>)">Удалить товар</button>
      </td>
    </tr>
  <?php endforeach;?>

    <tr>
       <form class="" action="" method="post">
       <td></td>
       <td><input  type="text" name="name_add" value=""></td>
       <td><select name="category_add"><?php foreach (Model::get_data() as $category):?><option value="<?php echo $category['id'].'-'.$category['name']; ?>"><?php echo $category['id'].'-'.$category['name']; ?></option><?php endforeach; ?></select></td>

       <td><input name="code_add" type="text" value=""></td>
       <td><input name="price_add" type="text" value=""></td>
       <td><select name="availability_add"><option value="Да">Да</option><option value="Нет" >Нет</option></select></td>

       <td><input type="text" name="brand_add" value=""></td>
       <td><input type="text" name="description_add" value=""></td>
       <td><select name="is_new_add"><option value="Да">Да</option><option value="Нет">Нет</option></select></td>
       <td><select name="is_recommended_add"><option value="Да">Да</option><option value="Нет" >Нет</option></select></td>
       <td><select name="status_add"><option value="Да">Да</option><option value="Нет" >Нет</option></select></td>

       <td><input type="file" name="image_add" value=""></td>
       <td><input type="submit" name="add_product" value="Добавить"></td>
       </form>
     </tr>


</table>
<?php else: ?>
  <h1 style="color: red;">У вас нет прав доступа к данной панели!</h1>
<?php endif; ?>
<script type="text/javascript">

function delete_product(id){





        $.ajax({
            type: 'POST',
            url: '#',
            data: {
                delete_product: id
            },
            success: function(response){
                $('body').html('<body>'+response+'</body>');
            }
        });


}


</script>
