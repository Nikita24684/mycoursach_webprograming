

<?php if(isset($_SESSION['logged_user'])): ?>

<div class="cabinet">

<h1>Личный кабинет</h1>

<h2>Здраствуйте <?php echo $_SESSION['logged_user']['name']; ?></h2>

<a class="a_cabinet" href="/my_cabinet/edit_user">Редактировать данные пользователя</a><br>

<a class="a_cabinet" href="/my_cabinet/logout">Выйти</a><br>

</div>

<?php else: ?>

<h1 style="color: red;">У вас нет прав доступа к данной панели!</h1>

<?php endif; ?>
