
<?php if(my_cabinet_Model::checkAdmin()): ?>
<p>Внимание! Если вы удаляете категорию, то вы удаляете ее вместе с товарами, которые входят в неё!</p>

<table border="1px">
  <tr>
    <th>Категории</th>
  </tr>
  <?php foreach ($data as $category): ?>
    <tr>
      <td><?php echo $category['id']; ?></td>
      <td>
        <form id="<?php echo $category['id']; ?>" class="form-editor" action="#" method="post">
          <input id="<?php echo $category['id'].'_id'; ?>" class="input_text" type="text" name="data" value="<?php echo $category['name']; ?>">
            <input type="submit" name="save" value="Сохранить">
        </form>
        <form id="<?php echo $category['id']; ?>" class="form-deleter" action="#" method="post">
            <input type="submit" name="delete" value="Удалить">
        </form>
      </td>
    </tr>

  <?php endforeach; ?>
</table>
<form class="form-add" action="#" method="post">
  <input id="input_add" type="text" name="data" value="">
  <input type="submit" name="added" value="Добавить категорию товаров">

</form>
<?php else: ?>
  <h1 style="color: red;">У вас нет прав доступа к данной панели!</h1>
<?php endif; ?>
<script type="text/javascript">
$(document).ready(function(){

    $('.form-editor').submit(function(event){

        //event.preventDefault();
        var id=$(this).attr('id');
        var value=$('#'+id+'_id').val();

        $.ajax({
            type: $(this).attr('method'),
            url: $(this).attr('action'),
            data: {
              id: id,
              save: value
            },
            success: function(response){

                $('body').html('<body>'+response+'</body>');
                //alert(value);
            },
        });

    });

    $('.form-add').submit(function(event){


        //event.preventDefault();
        var v=$('#input_add').val();

        $.ajax({
            type: $(this).attr('method'),
            url: $(this).attr('action'),
            data: {
              add: v
            },
            success: function(response){
                $('body').html('<body>'+response+'</body>');
            },
        });
    });

        $('.form-deleter').submit(function(event){


            //event.preventDefault();
            var v=$(this).attr('id');

            $.ajax({
                type: $(this).attr('method'),
                url: $(this).attr('action'),
                data: {
                  delete: v
                },
                success: function(){
                    //alert(v);
                },
            });
        });



});
</script>
