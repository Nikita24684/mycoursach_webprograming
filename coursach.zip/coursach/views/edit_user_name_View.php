

<?php if(isset($_SESSION['logged_user'])): ?>

<form class="name_edit" action="#" method="POST">

<p>
<p><strong>Ваше новое имя</strong></p>
<input type="text" name="name" value="<?php echo $_POST['name']; ?>">
</p>

<button type="submit" name="do_edit_name">Изменить</button>
</form>

<?php else: ?>
  <h1 style="color: red;">У вас нет прав доступа к данной панели!</h1>
<?php endif; ?>
