<!DOCTYPE html>
<html lang="ru" dir="ltr">
  <head>

    <meta charset="utf-8">

    <title>Coursach</title>

    <script type="text/javascript" src="<?php ROOT ?>/views/js/jquery.js"></script>





    <script type="text/javascript" src="<?php ROOT ?>/views/js/cart.js?v=100"></script>
    <link rel="stylesheet" href="<?php ROOT ?>/views/css/template_main.css">


  </head>
  <body>
    <center><a class="ah1" href="/"><h1>Интернет-магазин "Курсач"</h1></a></center>

    <div class="service_links">
    <ul class="ul_service_links">
    <?php if(!isset($_SESSION['logged_user'])): ?>
    <li class="li_service_links"><h3><a class="menublock" href="/check_in">Регистрация</a></h3></li>
    <?php endif; ?>
    <?php if(!isset($_SESSION['logged_user'])): ?>
    <li class="li_service_links"><h3><a class="menublock" href="/login">Авторизация</a></h3></li>
    <?php endif; ?>
    <?php if(isset($_SESSION['logged_user'])): ?>
    <li class="li_service_links"><h3><a class="menublock" href="/my_cabinet">Личный кабинет</a></h3></li>
    <?php endif; ?>

    <li id="cart" class="li_service_links"><h3><a class="menublock" href="/cart">Корзина(<span id="cart_count"><?php if(!empty($_SESSION['products_cart'])) echo array_sum($_SESSION['products_cart']); else echo 0;  ?></span>)</a></h3></li>
    </ul>
    </div>

    <div class="section">
    <ul class="ul_cat">
    <?php foreach(Model::get_data() as $categoria): ?>
        <li class="li_cat"><h3><a class="menublock <?php if(end(explode('/', $_SERVER['REQUEST_URI']))==$categoria['id'] and explode('/', $_SERVER['REQUEST_URI'])[1]=='category') echo 'active'; ?>" href = "/category/index/<?php echo $categoria['id'];?>"><?php echo $categoria['name']; ?></a></h3></li>
    <?php endforeach; ?>
    </ul>
    </div></body>



</html>
