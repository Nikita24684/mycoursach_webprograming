
<form class="login" action="#" method="POST">
            <div>
                <pre><label>E-mail: </label></pre> <input type="email" name="email" value="<?php echo @$data['email']; ?>">
            </div>

            <div>
                <pre><label>Пароль:</label></pre> <input type="password" name="password" value="<?php echo @$data['password']; ?>">
            </div>

            <div>
                <button class="login_button" type="submit" name="do_login">Войти</button>
            </div>
        </form>
