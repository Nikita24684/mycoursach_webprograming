
<div class="content">
  <h2>Каталог товаров</h2>
<?php foreach ($data as $product): ?>
  <div class="content_item">
  <a class="content_item_a" href="/product/index/<?php echo $product['id']; ?>"><div class="">

    <p><?php echo $product['name']; ?></p>
  </div></a>
  <img src=<?php if($product['image']!=NULL) echo '/'.$product['image']; else echo '/views/images/not_image.png'; ?> style="width: 90%; height: 50%;" alt="">
  <p><?php echo $product['price']; ?> грн</p>
  <button type="button" name="button" onclick="add_to_cart(<?php echo $product['id']; ?>)">В корзину</button>
  </div>
<?php endforeach; ?>
</div>
