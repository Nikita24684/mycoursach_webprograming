<?php

if(!empty($_SESSION['products_cart'])) echo array_sum($_SESSION['products_cart']); else echo 0;

 ?>
