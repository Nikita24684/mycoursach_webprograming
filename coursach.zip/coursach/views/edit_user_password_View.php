

<?php if(isset($_SESSION['logged_user'])): ?>

<form class="password_edit" action="#" method="POST">

<p>
<p><strong>Ваш новый пароль</strong></p>
<input type="password" name="password" value="<?php echo $data['password']; ?>">
</p>
<p>
<p><strong>Повторите ваш новый пароль</strong></p>
<input type="password" name="password_2" value="<?php echo $data['password_2']; ?>">
</p>

<button type="submit" name="do_edit_password">Изменить</button>
</form>

<?php else: ?>
  <h1 style="color: red;">У вас нет прав доступа к данной панели!</h1>
<?php endif; ?>
