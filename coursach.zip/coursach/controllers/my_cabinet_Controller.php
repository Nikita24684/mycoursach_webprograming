<?php

class my_cabinet_Controller{

    function action_index(){

        if(my_cabinet_Model::checkAdmin()){
            require ROOT.'/views/template_View.php';
            require ROOT.'/views/my_cabinet_admin_View.php';
        }

        else{
            require ROOT.'/views/template_View.php';
            require ROOT.'/views/my_cabinet_View.php';
        }


    }

    function action_logout()
    {
        unset($_SESSION['logged_user']);

        header('Location: /');

        return true;
    }

    function action_edit_user(){
        require ROOT.'/views/template_View.php';
        require ROOT.'/views/edit_user_View.php';

    }

    function action_edit_user_name(){

      $data=$_POST;
      $name=$data['name'];

      if(isset($data['do_edit_name'])){

          $errors=array();
          if(trim($data['name']) == ''){
              $errors[] = 'Введите имя!';
          }

          if($name == $_SESSION['logged_user']['name']){
              $errors[] = 'Это имя уже имеется.';
          }

          if(empty($errors)){
              $id = $_SESSION['logged_user']['id'];
              my_cabinet_Model::edit_data_name($id, $name);
              echo '<script type="text/javascript">alert("Вы успешно изменили ваше имя");</script>';

          }

          else{

              echo '<script type="text/javascript">alert("'.array_shift($errors).'");</script>';
          }
      }
      require ROOT.'/views/template_View.php';
      require ROOT.'/views/edit_user_name_View.php';


  }

    function action_edit_user_email(){

        $data=$_POST;
        $email=$data['email'];
      //  $res=false;

        if(isset($data['do_edit_email'])){

            $errors=array();
            if(trim($data['email']) == ''){
                $errors[] = 'Введите email!';
            }
            if($email == $_SESSION['logged_user']['email']){
                $errors[] = 'Этот email уже привязан.';
            }
            if(my_cabinet_Model::check_user(trim($data['email']))!=NULL){
                $errors[] = 'Пользователь с таким email существует!';
            }

            if(empty($errors)){
                $id = $_SESSION['logged_user']['id'];
                my_cabinet_Model::edit_data_email($email, $id);
                //header('Location:/');
                echo '<script type="text/javascript">alert("Вы успешно изменили email!");</script>';

            }

            else{

                echo '<script type="text/javascript">alert("'.array_shift($errors).'");</script>';

            }

      }
      require ROOT.'/views/template_View.php';
      require ROOT.'/views/edit_user_email_View.php';

    }

    function action_edit_user_password(){
        $data=$_POST;
        $password = $data['password'];
        if(isset($data['do_edit_password'])){

            $errors=array();

            if(password_verify($password, $_SESSION['logged_user']->password)){
                $errors[] = 'У вас этот пароль уже установлен!';
            }

            if($password!=$data['password_2']){
                $errors[] = 'Повторный пароль введён неверно!';
            }

            if(empty($errors)){

                $id = $_SESSION['logged_user']['id'];

                my_cabinet_Model::edit_data_password($id, $password);

                echo '<script type="text/javascript">alert("Вы успешно изменили пароль!");</script>';


            }

            else{
                echo '<script type="text/javascript">alert("'.array_shift($errors).'");</script>';
            }
        }

        require ROOT.'/views/template_View.php';
        require ROOT.'/views/edit_user_password_View.php';

    }

    function action_manage_of_orders(){

        $data=my_cabinet_Model::list_of_orders();

        if(!empty($_POST['button'])){

            if(my_cabinet_Model::checkAdmin()){

                $id=$_POST['button'];

                $status=$_POST['status'];

                if($status==0){
                    my_cabinet_Model::accept_order($id);
                }
                else{

                    my_cabinet_Model::unaccept_order($id);

                }

                unset($_POST['button']);
            }
            else{
                unset($_POST['button']);
            }

        }

        if(!empty($_POST['delete'])){
            if(my_cabinet_Model::checkAdmin()){
                $id = $_POST['delete'];
                my_cabinet_Model::delete_order($id);
                unset($_POST['delete']);
            }
            else{
                unset($_POST['delete']);
            }
        }


        require ROOT.'/views/template_View.php';
        require ROOT.'/views/manage_of_orders_View.php';

    }

    function action_manage_of_category(){

        $data=Model::get_data();

        if(!empty($_POST['save'])){
            if(my_cabinet_Model::checkAdmin()){
                my_cabinet_Model::edit_category($_POST['id'], $_POST['save']);

                unset($_POST['save']);
                unset($_POST['id']);
            }

            else{
                unset($_POST['save']);
                unset($_POST['id']);
            }

        }

        if(!empty($_POST['add'])){
            if(my_cabinet_Model::checkAdmin()){
                my_cabinet_Model::add_category($_POST['add']);
                unset($_POST['add']);
            }
            else{
                unset($_POST['add']);
            }

        }

        if(!empty($_POST['delete'])){
            if(my_cabinet_Model::checkAdmin()){
                my_cabinet_Model::delete_category($_POST['delete']);

                unset($_POST['delete']);
            }
            else{
                unset($_POST['delete']);
            }

        }

        require ROOT.'/views/template_View.php';
        require (ROOT.'/views/manage_of_category_View.php');

    }


    function action_manage_of_products(){

        $data=main_Model::get_data();

        if(isset($_POST['edit_product'])){
            if(my_cabinet_Model::checkAdmin()){

                if($_POST['availability']=='Да')
                    $availability=1;
                else{
                    $availability=0;
                }

                if($_POST['is_new']=='Да')
                    $is_new=1;
                else{
                    $is_new=0;
                }

                if($_POST['is_recommended']=='Да')
                    $is_recommended=1;
                else{
                    $is_recommended=0;
                }

                if($_POST['status']=='Да')
                    $status=1;
                else{
                    $status=0;
                }
                $category_id = explode('-',$_POST['category']);
                $category_id = $category_id[0];

                if(!empty($_FILES['image']['name'])){

                    $name = $_FILES['image']['name'];
                    $tmp_name = $_FILES['image']['tmp_name'];
                    move_uploaded_file($tmp_name, 'views/images/'.$name);
                    $path_img = 'views/images/'.$name;
                    unset($_FILES['image']);


                 }

                 else{
                     $path_img = NULL;
                 }

                 if($_POST['del_img']=='del_img')
                     my_cabinet_Model::delete_image_product($_POST['id']);

                 header('Location:/my_cabinet/manage_of_products');
                 my_cabinet_Model::edit_product($_POST['id'], $_POST['name'], $category_id, $_POST['code'], $_POST['price'], $availability, $_POST['brand'], $_POST['description'], $is_new, $is_recommended, $status, $path_img);
                //

            }
            else{
                unset($_POST['edit_product']);
            }
        }

        if(!empty($_POST['delete_product'])){
            if(my_cabinet_Model::checkAdmin()){
                $id= $_POST['delete_product'];
                //$id=explode('_', $_POST['delete_product']);
                //$id=$id[0];

                my_cabinet_Model::delete_product($id);
                unset($_POST['delete_product']);

            }
            else{
                unset($_POST['delete_product']);

            }
        }

        if(isset($_POST['add_product'])){
            if(my_cabinet_Model::checkAdmin()){
                if($_POST['availability_add']=='Да')
                    $availability=1;
                else{
                    $availability=0;
                }

                if($_POST['is_new_add']=='Да')
                    $is_new=1;
                else{
                    $is_new=0;
                }

                if($_POST['is_recommended_add']=='Да')
                    $is_recommended=1;
                else{
                    $is_recommended=0;
                }

                if($_POST['status_add']=='Да')
                    $status=1;
                else{
                    $status=0;
                }
                $category_id = explode('-',$_POST['category_add']);
                $category_id = $category_id[0];


                if(!empty($_FILES['image_add']['name'])){

                    $name_add = $_FILES['image_add']['name'];
                    $tmp_name_add = $_FILES['image_add']['tmp_name'];
                    move_uploaded_file($tmp_name_add, 'views/images/'.$name_add);
                    $path_img_add = 'views/images/'.$name_add;

                    unset($_FILES['image_add']);

                }

                else{
                $path_img_add = NULL;
                }

                header('Location:/my_cabinet/manage_of_products');
                my_cabinet_Model::add_product($_POST['name_add'], $category_id, $_POST['code_add'], $_POST['price_add'], $availability, $_POST['brand_add'], $_POST['description_add'], $is_new, $is_recommended, $status, $path_img_add);
                unset($_POST['add_product']);
            }

            else {
                unset($_POST['add_product']);
            }

        }

        require ROOT.'/views/template_View.php';
        require ROOT.'/views/manage_of_products_View.php';

    }

}

?>
