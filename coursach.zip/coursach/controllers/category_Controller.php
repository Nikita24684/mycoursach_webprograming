<?php

class category_Controller{

    function action_index(){

        

        $data = category_Model::get_data();
        require ROOT.'/views/template_View.php';
        require ROOT.'/views/category_View.php';

    }

    function action_addproduct(){
      $check_value=false;

      if(isset($_POST['id_add'])){

          if(isset($_SESSION['products_cart'])){

              foreach ($_SESSION['products_cart'] as $prod_item => &$value) {
                  if($prod_item==$_POST['id_add']){
                      $value+=1;
                      $check_value=true;
                      break;
                  }

              }

              if(!$check_value){
                  $_SESSION['products_cart']+=[$_POST['id_add'] => 1];
              }

          }
          else{
              $_SESSION['products_cart']=array();
              $_SESSION['products_cart']+=[$_POST['id_add'] => 1];
          }

          unset($_POST['id_add']);
          echo array_sum($_SESSION['products_cart']);
      }
    }

}

?>
