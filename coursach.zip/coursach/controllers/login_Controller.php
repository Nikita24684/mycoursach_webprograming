<?php

class login_Controller{

    function action_index(){

      $email=$_POST['email'];
      $password=$_POST['password'];

      if(isset($_POST['do_login'])){
          $errors=array();
          $user = login_Model::check_data_user($email);
      if($user){
          if(password_verify($password, $user['password'])){
            if($user['token']==null){
                $_SESSION['logged_user'] = $user;
                header('Location:/');
            }
            else{
              echo '<script type="text/javascript">alert("Вы не прошли верификацию! Пройдите пожалуйста!");</script>';
            }
                //echo "<p style='color: green;'>Авторизован!</p>";

          }
          else{
            echo "<script type='text/javascript'>alert('Не верный пароль!');</script>";
        }
    }
    else{
        echo "<script type='text/javascript'>alert('Такого пользователя не существует!');</script>";
    }
  }
      require ROOT.'/views/template_View.php';
      require ROOT.'/views/login_View.php';
      //$this->view->generate('template_View.php','login_View.php');

    }

}

?>
