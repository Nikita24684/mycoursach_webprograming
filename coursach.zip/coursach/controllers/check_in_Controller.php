<?php

class check_in_Controller{




    function action_index(){



      $data=$_POST;

      if(isset($data['do_check_in']) ){
  //здесь регистрируем
          $errors=array();
      if(trim($data['name']) == ''){
          $errors[] = 'Введите имя!';
      }
      if(trim($data['email']) == ''){
          $errors[] = 'Введите e-mail!';
      }
      if($data['password'] == ''){
          $errors[] = 'Введите пароль!';
      }
      if($data['password_2'] != $data['password']){
          $errors[] = 'Повторный пароль введён неверно!';
      }
      if(check_in_Model::check_user(trim($data['email']))!=NULL){
          $errors[] = 'Пользователь с таким e-mail существует!';
      }

      if(empty($errors)){
          check_in_Model::add_user($data);
          echo '<script type="text/javascript"> alert("Вы успешно зарегистрировались. Подтвердите свой e-mail, перейдя по ссылке!");</script>';
          unset($_POST['do_check_in']);
      }
      else{
          echo '<script type="text/javascript"> alert("'.array_shift($errors).'");</script>';
      }



    }
    $routes = explode('/', $_SERVER['REQUEST_URI']);
    if(empty($routes[3])){
        require ROOT.'/views/template_View.php';
        require ROOT.'/views/check_in_View.php';
    }
    else{
        check_in_Model::verification_user($routes[3]);
        require ROOT.'/views/template_View.php';
        echo '<h1 class="h3_cart">Вы прошли верификацию</h1>';
    }
  }

    //$this->view->generate('template_View.php', 'check_in_View.php');
}

?>
