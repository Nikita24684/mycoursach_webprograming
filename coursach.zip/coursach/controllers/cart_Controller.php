<?php

class cart_Controller{

    function action_index(){





        $data=array();
        $number=0;


        if(empty($_SESSION['products_cart']))
            unset($_SESSION['products_cart']);


        if(isset($_SESSION['products_cart']))
            foreach ($_SESSION['products_cart'] as $prod_item => $value) {

                $data[]=cart_Model::get_data_product($prod_item);

            }

        require ROOT.'/views/template_View.php';
        require ROOT.'/views/cart_View.php';
        //$this->view->generate('template_View.php', 'cart_View.php', $data) ;

    }

    function action_order_emiter(){

        if(isset($_POST['order_emiter'])){
            $data='';
            foreach ($_SESSION['products_cart'] as $prod_item => $value) {

                $data_i=cart_Model::get_data_product($prod_item);

                $data.='{id товара:'.$data_i['id'].', название:'.$data_i['name'].', цена:'.$data_i['price'].', количество:'.$value.'};';

            }





            cart_Model::add_order($_POST['user_name'], $_POST['number_phone'], $_POST['user_email'], $_POST['user_comment'], $_SESSION['logged_user']->id, $data);
            unset($_SESSION['products_cart']);
            unset($_POST['order_emiter']);



        }
        require ROOT.'/views/template_View.php';
        require ROOT.'/views/order_emiter_View.php';



    }
    function action_delproduct(){
      if(isset($_POST['id_del'])){






          if($_SESSION['products_cart'][$_POST['id_del']]==1){
              unset($_SESSION['products_cart'][$_POST['id_del']]);
              if(empty($_SESSION['products_cart'])){
                  unset($_SESSION['products_cart']);

              }

          }
          else{
              $_SESSION['products_cart'][$_POST['id_del']]-=1;
              if($_SESSION['products_cart'][$_POST['id_del']]<=0){
                  unset($_SESSION['products_cart'][$_POST['id_del']]);

              }

          }

          $data=array();

          if(isset($_SESSION['products_cart'])){
              foreach ($_SESSION['products_cart'] as $prod_item => $value) {

                  $data[]=cart_Model::get_data_product($prod_item);

              }



              unset($_POST['id_del']);

          }

              require ROOT.'/views/cart_View_AJAX.php';


      }
    }

    function action_countreducer(){
        if(!empty($_SESSION['products_cart']))
            echo array_sum($_SESSION['products_cart']);
        else{
            echo '0';
        }
    }
    function action_clearcart(){

      if(isset($_POST['clear_cart'])){

          unset($_SESSION['products_cart']);
          unset($_POST['clear_cart']);
          require ROOT.'/views/cart_View_AJAX.php';

      }


    }


}

?>
