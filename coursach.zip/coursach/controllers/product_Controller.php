<?php

class product_Controller{
    function action_index(){

        if(isset($_POST['id_add'])){

            if(isset($_SESSION['products_cart'])){

                foreach ($_SESSION['products_cart'] as $prod_item => &$value) {
                    if($prod_item==$_POST['id_add']){
                        $value+=1;
                        $check_value=true;
                        break;
                    }

                }

                if(!$check_value){
                    $_SESSION['products_cart']+=[$_POST['id_add'] => 1];
                }

            }
            else{
                $_SESSION['products_cart']=array();
                $_SESSION['products_cart']+=[$_POST['id_add'] => 1];
            }

            unset($_POST['id_add']);

        }


        $data = product_Model::get_data();
        require ROOT.'/views/template_View.php';
        require ROOT.'/views/product_View.php';


    }
}

?>
