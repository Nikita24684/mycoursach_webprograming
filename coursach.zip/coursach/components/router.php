<?php
class Router {

      static function start(){
     //Изначальное имя контроллера и по умолчанию выполняемое действие
        $controller_name = 'main';

        $action_name = 'index';

        $routes = explode('/', $_SERVER['REQUEST_URI']);

        if ( !empty($routes[1]) ){
            $controller_name = $routes[1];
        }

        if ( !empty($routes[2]) ){
            $action_name = $routes[2];
        }

  //      $model_name = $controller_name.'_Model';
        $controller_name = $controller_name.'_Controller';
        $action_name = 'action_'.$action_name;

      //  $model_file = $model_name.'.php';
      //  $model_path = 'models/'.$model_file;

    /*    if(file_exists($model_path)){
            require ROOT.'/models/'.$model_file;
        }*/

        $controller_file = $controller_name.'.php';
        $controller_path = 'controllers/'.$controller_file;

        if(file_exists(ROOT.'/'.$controller_path)){
             require ROOT.'/controllers/'.$controller_file;
        }
        else{
             require ROOT.'/views/404_page.php';
        }

        //$controller = new $controller_name;
        //$action = $action_name;


        if(method_exists($controller_name, $action_name)){
             $controller_name::$action_name();
        }
        else{
             require ROOT.'/views/404_page.php';
        }
}

}
?>
