<?php

/**
 * Автозагрузка классов
 */
function __autoload ($className) {

    //директории, в которых будет идти поиск классов
    require ROOT.'/models/'. $className . '.php';



}
?>
