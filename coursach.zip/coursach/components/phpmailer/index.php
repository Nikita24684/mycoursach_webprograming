<?php

require ROOT.'/components/phpmailer/phpmailer/PHPMailerAutoload.php';

$mail = new PHPMailer;

$mail->isSMTP();

$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username = 'myinternetmagazinephp@gmail.com'; // логин от вашей почты
$mail->Password = 'mysitephp2525'; // пароль от почтового ящика
$mail->SMTPSecure = 'ssl';
$mail->Port = '465';

$mail->CharSet = 'UTF-8';
$mail->From = 'myinternetmagazinephp@gmail.com'; // адрес почты, с которой идет отправка
$mail->FromName = 'My interner magazine PHP'; // имя отправителя
$mail->addAddress($data['email'], 'Имя');

//$mail->addCC('email3@email.com');

$mail->isHTML(true);

$mail->Subject = 'Регистрация';
$mail->Body = 'Ссылка на регистрацию: http://coursework.edu.ua/check_in/index/'.$token;
$mail->AltBody = 'Спасибо за регистрацию!';
$mail->addAttachment('img/Lighthouse.jpg', 'Картинка Маяк.jpg');
// $mail->SMTPDebug = 1;
$mail->send();
/*if( $mail->send() ){
	echo 'Письмо отправлено';
}else{
	echo 'Письмо не может быть отправлено. ';
	echo 'Ошибка: ' . $mail->ErrorInfo;
}*/

?>
