<?php


class DB{

    function getConnection(){

        $conn = new PDO("mysql:host=127.0.0.1;dbname=testsh;port=3307", 'root', 'root');
        return $conn;
        //echo "Connected to $dbname at $host successfully.";
    }

}
?>
