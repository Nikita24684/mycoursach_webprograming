<?php

class category_Model{


    function get_data(){
        $category_id = explode('/', $_SERVER['REQUEST_URI']);
        $category_id = $category_id[3];

        $db = DB::getConnection();

        $sql='SELECT * FROM product WHERE category_id = :category_id';

        $res = $db->prepare($sql);

        $res->bindParam(':category_id', $category_id, PDO::PARAM_INT);

        $res->execute();

        $data = $res->fetchAll(PDO::FETCH_ASSOC);

        return $data;

    }



}

?>
