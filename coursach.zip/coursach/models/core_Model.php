<?php

class Model
{

	/*
		Модель обычно включает методы выборки данных, это могут быть:
			> методы нативных библиотек pgsql или mysql;
			> методы библиотек, реализующих абстракицю данных. Например, методы библиотеки PEAR MDB2;
			> методы ORM;
			> методы для работы с NoSQL;
			> и др.
	*/

	// метод выборки данных
	  function get_data()
	  {

			  $db = DB::getConnection();

				$sql='SELECT id, name FROM category';

				$res = $db->prepare($sql);

				$res->execute();

				$category = $res->fetchAll(PDO::FETCH_ASSOC);

        return $category;
	  }





}
?>
