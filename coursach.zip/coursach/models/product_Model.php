<?php

class product_Model{

    function get_data(){
        $product_id = explode('/', $_SERVER['REQUEST_URI']);
        $id = $product_id[3];
        $db = DB::getConnection();
        $sql='SELECT * FROM product WHERE id = :id';

        $res = $db->prepare($sql);
        $res->bindParam(':id', $id, PDO::PARAM_INT);
        $res->execute();

        $data=$res->fetch(PDO::FETCH_ASSOC);
        //$data = R::getRow('SELECT * FROM product WHERE id = ? LIMIT 1', [$id]);
        return $data;
    }

}

?>
