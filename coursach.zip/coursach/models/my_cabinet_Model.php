<?php

class my_cabinet_Model{

    function get_data(){
        return $_SESSION['logged_user'];
    }
    function edit_data_password($id, $password){

        $hash_password=password_hash($password, PASSWORD_DEFAULT);

        $db = DB::getConnection();

        $sql='UPDATE user SET password = :password WHERE id = :id';

        $res = $db->prepare($sql);

        $res->bindParam(':id', $id, PDO::PARAM_INT);

        $res->bindParam(':password', $hash_password, PDO::PARAM_STR);

        $res->execute();

        $_SESSION['logged_user']['password'] = $hash_password;

        return true;

    }

    function edit_data_name($id, $name){

        $db = DB::getConnection();

        $sql = '
                UPDATE user
                     SET name = :name
                       WHERE id = :id
                ';

        $res = $db->prepare($sql);

        $res->bindParam(':id', $id, PDO::PARAM_INT);

        $res->bindParam(':name', $name, PDO::PARAM_STR);

        $_SESSION['logged_user']['name'] = $name;

        return $res->execute();

    }

    function edit_data_email($email, $id){

        $db = DB::getConnection();

        $sql = '
                UPDATE user
                     SET email = :email
                       WHERE id = :id
                ';

        $res = $db->prepare($sql);

        $res->bindParam(':id', $id, PDO::PARAM_INT);

        $res->bindParam(':email', $email, PDO::PARAM_STR);

        $_SESSION['logged_user']['email'] = $email;
        return $res->execute();

    }

    function check_user($email){

      $db = DB::getConnection();

      $sql = 'SELECT id, name FROM user
              WHERE email = :email';

      $res = $db->prepare($sql);

      $res->bindParam(':email', $email, PDO::PARAM_STR);

      $res->execute();

      $user = $res->fetchAll(PDO::FETCH_ASSOC);

      return $user;

    }

    function checkAdmin(){
        if ($_SESSION['logged_user']['role']=='admin'){
            return true;
        }

        else{
            return false;
        }

    }

    function list_of_orders(){

        $db = DB::getConnection();

        $sql = 'SELECT * FROM product_order ORDER BY user_phone';

        $res = $db->query($sql);

        $data = $res->fetchAll(PDO::FETCH_ASSOC);



        return $data;

    }

    function accept_order($id){

        $db = DB::getConnection();

        $sql = 'UPDATE product_order SET status = 1 WHERE id = :id';

        $res = $db->prepare($sql);

        $res->bindParam(':id', $id, PDO::PARAM_INT);

        $res->execute();

    }

    function unaccept_order($id){

      $db = DB::getConnection();

      $sql = 'UPDATE product_order SET status = 0 WHERE id = :id';

      $res = $db->prepare($sql);

      $res->bindParam(':id', $id, PDO::PARAM_INT);

      $res->execute();

    }

    function delete_order($id)
    {
        $db = DB::getConnection();

        $sql = 'DELETE FROM product_order WHERE id = :id';

        $res = $db->prepare($sql);

        $res->bindParam(':id', $id, PDO::PARAM_INT);

        $res->execute();

    }

    function edit_category($id, $name){

        $db = DB::getConnection();

        $sql = 'UPDATE category SET name = :name WHERE id = :id';

        $res = $db->prepare($sql);

        $res->bindParam(':id', $id, PDO::PARAM_INT);

        $res->bindParam(':name', $name, PDO::PARAM_STR);

        $res->execute();

    }

    function add_category($name){

        $db = DB::getConnection();

        $sql = 'INSERT INTO category(name) VALUES (:name)';

        $res = $db->prepare($sql);

        $res->bindParam(':name', $name, PDO::PARAM_STR);

        $res->execute();

    }

    function delete_category($id){

        $db = DB::getConnection();

        $sql = 'DELETE FROM category WHERE id = :id';

        $res = $db->prepare($sql);

        $res->bindParam(':id', $id, PDO::PARAM_INT);

        $res->execute();

    }

    function edit_product($id, $name, $category_id, $code, $price, $availability, $brand, $description, $is_new, $is_recommended, $status, $image){

        if($image==NULL){

            $db = DB::getConnection();

            $sql = 'UPDATE product SET name = :name, category_id = :category_id, code = :code, price = :price, availability = :availability, brand = :brand, description = :description, is_new = :is_new, is_recommended = :is_recommended, status = :status WHERE id = :id';

            $res = $db->prepare($sql);

            $res->bindParam(':id', $id, PDO::PARAM_INT);
            $res->bindParam(':name', $name, PDO::PARAM_STR);
            $res->bindParam(':category_id', $category_id, PDO::PARAM_INT);
            $res->bindParam(':code', $code, PDO::PARAM_INT);
            $res->bindParam(':price', $price, PDO::PARAM_INT);
            $res->bindParam(':availability', $availability, PDO::PARAM_STR);
            $res->bindParam(':brand', $brand, PDO::PARAM_STR);
            $res->bindParam(':description', $description, PDO::PARAM_STR);
            $res->bindParam(':is_new', $is_new, PDO::PARAM_INT);
            $res->bindParam(':is_recommended', $is_recommended, PDO::PARAM_INT);
            $res->bindParam(':status', $status, PDO::PARAM_INT);


            $res->execute();




        }

        else{
              $db = DB::getConnection();

              $sql = 'UPDATE product SET name = :name, category_id = :category_id, code = :code, price = :price, availability = :availability, brand = :brand, description = :description, is_new = :is_new, is_recommended = :is_recommended, status = :status, image = :image WHERE id = :id';

              $res = $db->prepare($sql);

              $res->bindParam(':id', $id, PDO::PARAM_INT);
              $res->bindParam(':name', $name, PDO::PARAM_STR);
              $res->bindParam(':category_id', $category_id, PDO::PARAM_INT);
              $res->bindParam(':code', $code, PDO::PARAM_INT);
              $res->bindParam(':price', $price, PDO::PARAM_INT);
              $res->bindParam(':availability', $availability, PDO::PARAM_STR);
              $res->bindParam(':brand', $brand, PDO::PARAM_STR);
              $res->bindParam(':description', $description, PDO::PARAM_STR);
              $res->bindParam(':is_new', $is_new, PDO::PARAM_INT);
              $res->bindParam(':is_recommended', $is_recommended, PDO::PARAM_INT);
              $res->bindParam(':status', $status, PDO::PARAM_INT);
              $res->bindParam(':image', $image, PDO::PARAM_STR);


              $res->execute();


        }

    }

    function delete_product($id){

        $db = DB::getConnection();

        $sql = 'DELETE FROM product WHERE id = :id';

        $res = $db->prepare($sql);

        $res->bindParam(':id', $id, PDO::PARAM_INT);

        $res->execute();

    }

    function delete_image_product($id){
        $db = DB::getConnection();

        $sql = 'SELECT image FROM product WHERE id = :id';

        $res = $db->prepare($sql);

        $res->bindParam(':id', $id, PDO::PARAM_INT);

        $res->execute();

        $pathname = $res->fetchColumn();

        unlink($pathname);

        $db = DB::getConnection();

        $sql = 'UPDATE product SET image = :image WHERE id = :id';
        $res = $db->prepare($sql);
        $null = null;
        $res->bindParam(':image', $null, PDO::PARAM_NULL);
        $res->bindParam(':id', $id, PDO::PARAM_INT);

        $res->execute();
    }

    function add_product($name, $category_id, $code, $price, $availability, $brand, $description, $is_new, $is_recommended, $status, $image){

        if($image==NULL){
            $db = DB::getConnection();

            $sql = 'INSERT INTO product(name, category_id, code, price, availability,
                                brand, description, is_new, is_recommended, status)
            VALUES (:name, :category_id, :code, :price, :availability,
                    :brand, :description, :is_new, :is_recommended, :status)';
            $res = $db->prepare($sql);


            $res->bindParam(':name', $name, PDO::PARAM_STR);
            $res->bindParam(':category_id', $category_id, PDO::PARAM_INT);
            $res->bindParam(':code', $code, PDO::PARAM_INT);
            $res->bindParam(':price', $price, PDO::PARAM_INT);
            $res->bindParam(':availability', $availability, PDO::PARAM_STR);
            $res->bindParam(':brand', $brand, PDO::PARAM_STR);
            $res->bindParam(':description', $description, PDO::PARAM_STR);
            $res->bindParam(':is_new', $is_new, PDO::PARAM_INT);
            $res->bindParam(':is_recommended', $is_recommended, PDO::PARAM_INT);
            $res->bindParam(':status', $status, PDO::PARAM_INT);

            $res->execute();

            print_r($db->errorInfo());

            //$res->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }

        else{

          $db = DB::getConnection();

          $sql = 'INSERT INTO product(name, category_id, code, price, availability,
                              brand, description, is_new, is_recommended, status)
          VALUES (:name, :category_id, :code, :price, :availability,
                  :brand, :description, :is_new, :is_recommended, :status, :image)';
          $res = $db->prepare($sql);


          $res->bindParam(':name', $name, PDO::PARAM_STR);
          $res->bindParam(':category_id', $category_id, PDO::PARAM_INT);
          $res->bindParam(':code', $code, PDO::PARAM_INT);
          $res->bindParam(':price', $price, PDO::PARAM_INT);
          $res->bindParam(':availability', $availability, PDO::PARAM_STR);
          $res->bindParam(':brand', $brand, PDO::PARAM_STR);
          $res->bindParam(':description', $description, PDO::PARAM_STR);
          $res->bindParam(':is_new', $is_new, PDO::PARAM_INT);
          $res->bindParam(':is_recommended', $is_recommended, PDO::PARAM_INT);
          $res->bindParam(':status', $status, PDO::PARAM_INT);
          $res->bindParam(':image', $image, PDO::PARAM_STR);


          $res->execute();

        }

    }

}

?>
