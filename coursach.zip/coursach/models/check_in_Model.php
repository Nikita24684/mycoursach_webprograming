<?php

class check_in_Model{

    function add_user($data){
        $token = time();
        $db = DB::getConnection();
        $role="user";
        $sql = 'INSERT INTO user(name, email, token, role, password)
        VALUES (:name, :email, :token, :role, :password)';
        $res = $db->prepare($sql);
      //все хорошо регисрируемся
        $res->bindParam(':name', $data['name'], PDO::PARAM_STR);
        $res->bindParam(':email', $data['email'], PDO::PARAM_STR);
        $res->bindParam(':token', $token, PDO::PARAM_STR);
        $res->bindParam(':role', $role, PDO::PARAM_STR);
        $res->bindParam(':password', password_hash($data['password'], PASSWORD_DEFAULT), PDO::PARAM_STR);
        $res->execute();
        require ROOT.'/components/phpmailer/index.php';
    }

    function check_user($email){

      $db = DB::getConnection();

      $sql = 'SELECT id, name FROM user
              WHERE email = :email';

      $res = $db->prepare($sql);

      $res->bindParam(':email', $email, PDO::PARAM_STR);

      $res->execute();

      $user = $res->fetchAll(PDO::FETCH_ASSOC);

      return $user;

    }
    function verification_user($token){
      $db = DB::getConnection();

      $sql = '
              UPDATE user
                   SET token = null
                     WHERE token = :token
              ';
      $res = $db->prepare($sql);

      $res->bindParam(':token', $token, PDO::PARAM_STR);

      $res->execute();

      $user = $res->fetchAll(PDO::FETCH_ASSOC);
      
      return true;
    }

}





?>
