<?php

class main_Model{

    function get_data(){

        $db = DB::getConnection();

        $sql = 'SELECT * FROM product';

        $res = $db->query($sql);

      //  $res->execute();

        $data=$res->fetchAll(PDO::FETCH_ASSOC);

        //$data = R::getAll('SELECT * FROM product');
        return $data;



    }

}

?>
