<?php

class login_Model{

    function check_data_user($email){

      $db = DB::getConnection();

      $sql = 'SELECT * FROM user
              WHERE email = :email';

      $res = $db->prepare($sql);

      $res->bindParam(':email', $email, PDO::PARAM_STR);

      $res->execute();

      $user = $res->fetch(PDO::FETCH_ASSOC);

      if(!empty($user)){
          return $user;
      }

      else {
          return false;
      }





    }

}

?>
