<?php

class cart_Model{

    function get_data_product($id){

        $db = DB::getConnection();
        $sql='SELECT * FROM product WHERE id = :id';

        $res = $db->prepare($sql);
        $res->bindParam(':id', $id, PDO::PARAM_INT);
        $res->execute();

        $data=$res->fetch(PDO::FETCH_ASSOC);

        //$data = R::getRow('SELECT * FROM product WHERE id = ? LIMIT 1', [$id]);
        return $data;

    }

    function add_order($user_name, $number_phone, $user_email, $comment, $user_id, $data){

        $db = Db::getConnection();

        $sql = 'INSERT INTO product_order(user_name, user_phone, user_email, user_comment, user_id, products)
        VALUES (:userName, :userPhone, :userEmail, :userText, :userId, :products)';

        $res = $db->prepare($sql);
        $res->bindParam(':userName', $user_name, PDO::PARAM_STR);
        $res->bindParam(':userPhone', $number_phone, PDO::PARAM_STR);
        $res->bindParam(':userEmail', $user_email, PDO::PARAM_STR);
        $res->bindParam(':userText', $comment, PDO::PARAM_STR);
        $res->bindParam(':userId', $user_id, PDO::PARAM_INT);
        $res->bindParam(':products', $data, PDO::PARAM_STR);
        $res->execute();

    }


    }



?>
