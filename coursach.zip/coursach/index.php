<?php
define('ROOT', dirname(__FILE__));

require __DIR__.'/models/core_Model.php';


require __DIR__.'/components/router.php';
require __DIR__.'/components/db.php';

require __DIR__.'/components/autoload.php';



session_start();

Router::start();

?>
